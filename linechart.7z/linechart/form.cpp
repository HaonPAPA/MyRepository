#include "form.h"
#include "ui_form.h"

Form::Form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form)
{
    ui->setupUi(this);    

    QLineSeries *series = new QLineSeries();
    series->setUseOpenGL(true);

    series->append(0, 6);
    series->append(1, 4);
    series->append(2, 8);
    series->append(3, 4);
    series->append(4, 5);
    *series << QPointF(5, 1) << QPointF(6, 3) << QPointF(7, 6) << QPointF(8, 3) << QPointF(9, 2);

    m_pchart = new QChart();
    m_pchart->legend()->hide();
    m_pchart->addSeries(series);
    m_pchart->createDefaultAxes();
    m_pchart->setTitle("Simple line chart example");

    m_pchartV = new QChartView(m_pchart);
    m_pchartV->setRenderHint(QPainter::Antialiasing);

    this->ui->horizontalLayout_2->addWidget(m_pchartV);

    this->connect(this->ui->pushButton, &QPushButton::clicked, this, &Form::ClickedBtn1);
    this->connect(this->ui->pushButton_2, &QPushButton::clicked, this, &Form::ClickedBtn2);
}

Form::~Form()
{
    delete ui;
}

void Form::AddSeries()
{
    QLineSeries *series = new QLineSeries();
    series->setUseOpenGL(true);

    for (int i = 0; i < 10; i++)
    {
        int qRan1 = QRandomGenerator::global()->bounded(0, 9);
        series->append(i, qRan1);
    }

    m_pchart->addSeries(series);
}

void Form::ClickedBtn1()
{
    AddSeries();
}

void Form::ClickedBtn2()
{
    cDialog* w = new cDialog(this);
    w->setGeometry(this->geometry());
    w->move(0, 0);
    w->exec();
}
