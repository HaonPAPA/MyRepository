#ifndef CDIALOG_H
#define CDIALOG_H

#include <QDialog>

namespace Ui {
class cDialog;
}

class cDialog : public QDialog
{
    Q_OBJECT

public:
    explicit cDialog(QWidget *parent = nullptr);
    ~cDialog();

private:
    Ui::cDialog *ui;
};

#endif // CDIALOG_H
