#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>
#include <qchart.h>
#include <qrandom.h>
#include <cdialog.h>

using namespace QtCharts;

namespace Ui {
class Form;
}

class Form : public QWidget
{
    Q_OBJECT
private:
    Ui::Form *ui;
    QChart* m_pchart;
    QChartView* m_pchartV;

public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();

    void AddSeries();

public slots:
    void ClickedBtn1();
    void ClickedBtn2();


};

#endif // FORM_H
