#include "cdialog.h"
#include "ui_cdialog.h"

cDialog::cDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::cDialog)
{
    ui->setupUi(this);

    this->setWindowFlags(Qt::FramelessWindowHint);
    this->setStyleSheet("QDialog{background-color: rgba(255, 0, 0, 100);}");

    QWidget* w = new QWidget();
    w->setStyleSheet("QWidget{background-color: rgb(0, 0, 255);}");
    w->setFixedSize(this->width()*70/100, this->height()*70/100);
    this->ui->horizontalLayout_2->addWidget(w);
}

cDialog::~cDialog()
{
    delete ui;
}
